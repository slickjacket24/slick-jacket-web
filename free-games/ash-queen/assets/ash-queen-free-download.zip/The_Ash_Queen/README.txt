THE ASH QUEEN: ASCENSION OF THE TITAN
FREE DOWNLOAD | A Slick Jacket Game

A simple fantasy boss fight you can play on your computer.

QUICK START
1. Download this ZIP file.
2. Extract / unzip it (do not run the game inside the ZIP).
3. Open the folder named The_Ash_Queen.
4. Double-click index.html. It should open in your web browser.
5. Click BEGIN ASCENSION to play.

CONTROLS
A / D or Left / Right Arrow: Move
W or Space: Jump
J or Mouse Click: Sword slash / reflect projectiles
K or Shift: Shadow dash
Collect hearts to heal and stars to rally allied knights.

IMPORTANT
- Best played on a desktop or laptop with a keyboard.
- No installer or account required. This is an HTML5 browser game.
- Keep index.html and both JPG image files in the same folder.
- Game runs locally in a modern browser. Google Fonts may require internet;
  system fonts are used if unavailable.
- Audio starts after browser interaction; check device volume if silent.

Slick Jacket | Weird by Design.
